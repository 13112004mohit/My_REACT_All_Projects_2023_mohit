import React from 'react'
import './login.css'
import { NavLink } from 'react-router-dom';

const Login = () => {
  return (
    <>

        <section className="login_main_pg">
           <div className="one_col_">
              <div className="form_">
                 <div className="smallboximg_">
                     <img src="logo.png" alt="" />
                 </div>
                <form id='form_boxs' action="">
                    <input placeholder=' enter your email' className='loginname' type="email" name="" id="" />
                    <input placeholder=' enter your password' className='loginpassword' type="password" name="" id="" />
                    <button type="submit" style={{borderRadius:'.5rem', width:'11rem',padding:'.3rem 0',background:'#fa5131',color:'white'}}>login</button>
                    <div className="smallbox">
                      <p>forget password</p>
                      <p>
                         <NavLink to={'/'} >signup</NavLink>
                      </p>
                    </div>
                </form>
              </div>
           </div>
        </section>
    
    </>
  )
}

export default Login;