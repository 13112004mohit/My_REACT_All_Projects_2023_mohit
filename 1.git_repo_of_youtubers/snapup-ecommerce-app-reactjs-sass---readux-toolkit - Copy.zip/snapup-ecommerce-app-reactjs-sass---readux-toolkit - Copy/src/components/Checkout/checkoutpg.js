import React from 'react'
import './checkout.css' 
import { NavLink } from 'react-router-dom';

const Login = () => {
  return (
    <>

        <section className="login_main_pg">
           <div className="one_col__checkout">
              
              <div className="first_con_img">
                  <img src="https://png.pngtree.com/png-clipart/20220601/original/pngtree-business-mobile-based-marketplace-png-image_7847093.png" alt="" />
              </div>
              <h1>your order is on the way</h1>
               
              <NavLink onClick={()=>{ window.scrollTo({top:0 ,left:0 ,behavior:'auto'})}} to="/">
              <button className='cart_continue_shopping'>Continue Shopping</button>
            </NavLink>

           </div>
        </section>
    
    </>
  )
}

export default Login;